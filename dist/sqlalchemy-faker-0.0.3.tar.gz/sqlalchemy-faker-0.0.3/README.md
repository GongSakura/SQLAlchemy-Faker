# SQLAlchemy-Faker

The project is designed for generating fake data for SQLAlchemy ORM within one step !
