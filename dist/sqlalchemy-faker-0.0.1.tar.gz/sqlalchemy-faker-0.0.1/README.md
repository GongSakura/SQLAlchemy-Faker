# SQLFaker
The project is designed for generating fake data for the majority of databases within one step !
